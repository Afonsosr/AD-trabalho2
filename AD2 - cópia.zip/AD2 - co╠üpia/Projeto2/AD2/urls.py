from django.contrib import admin
from django.urls import path, include
from .views import home

urlpatterns = [
    path('', home, name='home'),  # Página inicial
    path('gpc/', include('GPC.urls')),  # URLs do GPC
    path('glm/', include('GLM.urls')),  # URLs do GLM
    path('admin/', admin.site.urls),
]
