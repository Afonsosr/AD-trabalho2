from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.gpc_login, name='gpc_login'),
    path('med/', views.med_home, name='med_home'),  # Página do Médico
    path('enf/', views.enf_home, name='enf_home'),  # Página do Enfermeiro
    path('uten/', views.uten_home, name='uten_home'),  # Página do Utente
    path('far/', views.far_home, name='far_home'),

    path('listar-medicos/', views.listar_medicos, name='listar_medicos'),
    path('procurar_medico_nome/', views.procurar_medico_nome, name='procurar_medico_nome'),
    path('procurar_medico_especialidade/', views.procurar_medico_especialidade, name='procurar_medico_especialidade'),
    path('procurar_enfermeiro_especialidade/', views.procurar_enfermeiro_especialidade, name='procurar_enfermeiro_especialidade'),
    path('listar_enfermeiros/', views.listar_enfermeiros, name='listar_enfermeiros'),
    path('adicionar_enfermeiro/', views.adicionar_enfermeiro, name='adicionar_enfermeiro'),
    path('adicionar_medico/', views.adicionar_medico, name='adicionar_medico'),
    path('listar_utentes/', views.listar_utentes, name='listar_utentes'),
    path('listar_farmaceuticos/', views.listar_farmaceuticos, name='listar_farmaceuticos'),
    path('criar_consulta/', views.criar_consulta, name='criar_consulta'),
    path('adicionar_utente/', views.adicionar_utente, name='adicionar_utente'),
    path('procurar_utente_nome/', views.procurar_utente_nome, name='procurar_utente_nome'),
    path('procurar_enfermeiro_nome/', views.procurar_enfermeiro_nome, name='procurar_enfermeiro_nome'),
]
