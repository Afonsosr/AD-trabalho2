import uuid
from django.db import models

class Medico(models.Model):
    id = models.CharField(max_length=36, primary_key=True, default=uuid.uuid4, editable=False)
    nome = models.CharField(max_length=100)
    especialidade = models.CharField(max_length=100, blank=False)
    contacto = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.nome

class Enfermeiro(models.Model):
    id = models.CharField(max_length=36, primary_key=True, default=uuid.uuid4, editable=False)
    nome = models.CharField(max_length=100)
    especialidade = models.CharField(max_length=100, blank=False)
    contacto = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.nome

class Farmaceutico(models.Model):
    id = models.CharField(max_length=36, primary_key=True, default=uuid.uuid4, editable=False)
    nome = models.CharField(max_length=100)
    contacto = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.nome

class Utente(models.Model):
    GENERO_CHOICES = [
        ('M', 'Masculino'),
        ('F', 'Feminino'),
        ('O', 'Outro'),
    ]

    nome = models.CharField(max_length=200)
    genero = models.CharField(max_length=1, choices=GENERO_CHOICES)
    data_nascimento = models.DateField()
    medicação_regular = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.nome

class Medicamento(models.Model):
    id = models.CharField(max_length=36, primary_key=True, default=uuid.uuid4, editable=False)
    nome = models.CharField(max_length=200)
    descricao = models.TextField()
    fornecedor = models.CharField(max_length=200)
    quantidade_stock = models.IntegerField()

    def __str__(self):
        return self.nome

class Consulta(models.Model):
    utente = models.ForeignKey(Utente, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE)
    enfermeiro = models.ForeignKey(Enfermeiro, null=True, blank=True, on_delete=models.SET_NULL)
    data_consulta = models.DateTimeField()
    descricao = models.TextField()
    medicamento = models.ForeignKey(Medicamento, null=True, blank=True, on_delete=models.CASCADE)  # Referência direta
    quantidade = models.IntegerField(null=True, blank=True)  # Permite valores nulos e em branco

    def __str__(self):
        return f'Consulta de {self.utente.nome} com {self.medico.nome}'

