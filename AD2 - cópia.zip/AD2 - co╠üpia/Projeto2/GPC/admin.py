from django.contrib import admin
from .models import Medico, Enfermeiro, Utente, Consulta, Medicamento, Farmaceutico

admin.site.register(Medico)
admin.site.register(Enfermeiro)
admin.site.register(Utente)
admin.site.register(Consulta)
admin.site.register(Medicamento)
admin.site.register(Farmaceutico)