from django.shortcuts import render, redirect
from django.utils import timezone
from .models import Medico, Utente, Consulta, Medicamento, Enfermeiro, Farmaceutico


# Usuários válidos e suas senhas com suas páginas de destino
USERS = {
    'med': {'password': 'med', 'redirect': 'med_home'},
    'enf': {'password': 'enf', 'redirect': 'enf_home'},
    'uten': {'password': 'uten', 'redirect': 'uten_home'},
    'ges': {'password': 'ges', 'redirect': 'ges_home'},
}

#Fazer login no gpc e ir para a página de cada pessoa

def gpc_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Validação do login
        user = USERS.get(username)
        if user and user['password'] == password:
            # Redireciona para a página específica do usuário
            return redirect(user['redirect'])
        else:
            # Envia mensagem de erro
            return render(request, 'gpc_login.html', {
                'error': 'Usuário ou senha inválidos. Tente novamente.'
            })
    return render(request, 'gpc_login.html')


def med_home(request):
    return render(request, 'med_home.html')


def enf_home(request):
    return render(request, 'enf_home.html')


def uten_home(request):
    return render(request, 'uten_home.html')


def ges_home(request):
    return render(request, 'ges_home.html')


def far_home(request):
    return render(request, 'far_home.html')

def listar_medicos(request):

    medicos = Medico.objects.all().order_by('nome')  # Ordena os médicos pelo nome em ordem alfabética

    return render(request, 'listar_medicos.html', {'medicos': medicos})

def procurar_medico_nome(request):
    medicos = []
    if 'nome' in request.GET:
        nome = request.GET['nome']
        medicos = Medico.objects.filter(nome__icontains=nome)

    return render(request, 'procurar_medico_nome.html', {'medicos': medicos})

def procurar_medico_especialidade(request):
    medicos = []
    if 'especialidade' in request.GET:
        especialidade = request.GET['especialidade']
        medicos = Medico.objects.filter(especialidade__icontains=especialidade)

    return render(request, 'procurar_medico_especialidade.html', {'medicos': medicos})

def procurar_enfermeiro_especialidade(request):
    enfermeiros = []
    if 'especialidade' in request.GET:
        especialidade = request.GET['especialidade']
        enfermeiros = Enfermeiro.objects.filter(especialidade__icontains=especialidade)

    return render(request, 'procurar_enfermeiro_especialidade.html', {'enfermeiros': enfermeiros})

def procurar_enfermeiro_nome(request):
    enfermeiros = []
    if 'nome' in request.GET:
        nome = request.GET['nome']
        enfermeiros = Enfermeiro.objects.filter(nome__icontains=nome)

    return render(request, 'procurar_enfermeiro_nome.html', {'enfermeiros': enfermeiros})

def listar_enfermeiros(request):

    enfermeiros = Enfermeiro.objects.all().order_by('nome')

    return render(request, 'listar_enfermeiros.html', {'enfermeiros': enfermeiros})

def adicionar_enfermeiro(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        especialidade = request.POST.get('especialidade')
        contacto = request.POST.get('contacto')

        # Verifica se todos os campos foram preenchidos
        if nome and especialidade and contacto:
            Enfermeiro.objects.create(nome=nome, especialidade=especialidade, contacto=contacto)
            return redirect('listar_enfermeiros')
        else:
            return render(request, 'adicionar_enfermeiro.html', {'error': 'Todos os campos são obrigatórios.'})

    return render(request, 'adicionar_enfermeiro.html')


def listar_utentes(request):
    today = timezone.now()
    utentes = Utente.objects.all()

    for utente in utentes:
        # Filtra as consultas futuras para cada utente
        consultas_futuras = utente.consulta_set.filter(data_consulta__gte=today)
        utente.consultas_futuras = consultas_futuras

    return render(request, 'listar_utentes.html', {'utentes': utentes})

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.core.exceptions import ValidationError
from .models import Consulta, Medicamento, Medico, Enfermeiro, Utente

def criar_consulta(request):
    if request.method == 'POST':
        utente_id = request.POST.get('utente_id')
        medico_id = request.POST.get('medico_id')
        enfermeiro_id = request.POST.get('enfermeiro_id', None)
        medicamento_id = request.POST.get('medicamento_id', None)
        data_consulta = request.POST.get('data_consulta')
        descricao = request.POST.get('descricao')
        quantidade = int(request.POST.get('quantidade', 0))  # Garantir que seja um número inteiro

        # Obtendo os objetos do banco de dados
        utente = Utente.objects.get(id=utente_id)
        medico = Medico.objects.get(id=medico_id)
        enfermeiro = Enfermeiro.objects.get(id=enfermeiro_id) if enfermeiro_id else None
        medicamento = Medicamento.objects.get(id=medicamento_id) if medicamento_id else None

        # Verificar se a quantidade prescrita é válida
        if medicamento and quantidade > medicamento.quantidade_stock:
            # Se a quantidade prescrita for maior que a quantidade em estoque
            return render(request, 'criar_consulta.html', {
                'erro': f'Stoque insuficiente para o medicamento {medicamento.nome}. Apenas {medicamento.quantidade_stock} unidades disponíveis.',
                'medicos': Medico.objects.all(),
                'enfermeiros': Enfermeiro.objects.all(),
                'medicamentos': Medicamento.objects.all(),
                'utentes': Utente.objects.all()
            })

        # Se a quantidade for válida, atualiza o estoque
        if medicamento:
            medicamento.quantidade_stock -= quantidade
            medicamento.save()

        # Criar a consulta
        consulta = Consulta.objects.create(
            utente=utente,
            medico=medico,
            enfermeiro=enfermeiro,
            data_consulta=data_consulta,
            descricao=descricao,
            medicamento=medicamento,
            quantidade=quantidade if quantidade else None  # Quantidade não obrigatória
        )

        return render(request, 'criar_consulta.html', {
            'sucesso': 'Consulta criada com sucesso!',
            'medicos': Medico.objects.all(),
            'enfermeiros': Enfermeiro.objects.all(),
            'medicamentos': Medicamento.objects.all(),
            'utentes': Utente.objects.all()
        })

    # Caso não seja POST, apenas renderiza o formulário
    return render(request, 'criar_consulta.html', {
        'medicos': Medico.objects.all(),
        'enfermeiros': Enfermeiro.objects.all(),
        'medicamentos': Medicamento.objects.all(),
        'utentes': Utente.objects.all()
    })



def adicionar_utente(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        genero = request.POST.get('genero')
        data_nascimento = request.POST.get('data_nascimento')
        medicacao_regular = request.POST.get('medicacao_regular', '')

        if not nome or not genero or not data_nascimento:
            return render(request, 'adicionar_utente.html', {
                'error': 'Todos os campos obrigatórios devem ser preenchidos.'
            })

        # Criação do Utente
        Utente.objects.create(
            nome=nome,
            genero=genero,
            data_nascimento=data_nascimento,
            medicação_regular=medicacao_regular
        )

        return render(request, 'adicionar_utente.html', {
            'success': 'Utente adicionado com sucesso!'
        })

    return render(request, 'adicionar_utente.html')


def procurar_utente_nome(request):
    utentes_encontrados = None
    nome_pesquisado = None

    if request.method == 'GET':
        nome_pesquisado = request.GET.get('nome', '').strip()

        if nome_pesquisado:
            utentes_encontrados = Utente.objects.filter(nome__icontains=nome_pesquisado)

            # Filtra as consultas futuras para cada utente, igual ao que é feito na função listar_utentes
            for utente in utentes_encontrados:
                consultas_futuras = utente.consulta_set.filter(data_consulta__gte=timezone.now())
                utente.consultas_futuras = consultas_futuras

    return render(request, 'procurar_utente_nome.html', {
        'nome_pesquisado': nome_pesquisado,
        'utentes_encontrados': utentes_encontrados,
    })

def adicionar_medico(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        especialidade = request.POST.get('especialidade')
        contacto = request.POST.get('contacto')

        # Verifica se todos os campos foram preenchidos
        if nome and especialidade and contacto:
            Medico.objects.create(nome=nome, especialidade=especialidade, contacto=contacto)
            return redirect('listar_medicos')
        else:
            return render(request, 'adicionar_medico.html', {'error': 'Todos os campos são obrigatórios.'})

    return render(request, 'adicionar_medico.html')

def listar_farmaceuticos(request):

    farmaceuticos = Farmaceutico.objects.all().order_by('nome')

    return render(request, 'listar_farmaceuticos.html', {'farmaceuticos': farmaceuticos})