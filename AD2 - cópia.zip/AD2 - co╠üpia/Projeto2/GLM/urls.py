from django.urls import path
from . import views

urlpatterns = [
    path('glm/', views.glm_login, name='glm_login'),  # Página principal do GLM
    path('glm_home/', views.glm_home, name='glm_home'),
    path('medicamentos/', views.listar_medicamentos, name='listar_medicamentos'),
    path('criar_medicamento/', views.criar_medicamento, name='criar_medicamento'),
    path('procurar_medicamento_nome/', views.procurar_medicamento_nome, name='procurar_medicamento_nome'),
    path('aumentar_stock/', views.aumentar_stock, name='aumentar_stock'),
    path('alterar_fornecedor/', views.alterar_fornecedor, name='alterar_fornecedor'),
    path('remover_medicamento/', views.remover_medicamento, name='remover_medicamento'),
    path('listar_farmaceuticos2/', views.listar_farmaceuticos, name='listar_farmaceuticos2'),
    path('prescrever_medicamento/', views.prescrever_medicamento, name='prescrever_medicamento'),

]

