from django.shortcuts import render, redirect
from GPC.models import Medicamento, Farmaceutico, Utente
from django.shortcuts import get_object_or_404
from django.http import JsonResponse


def glm_home(request):
    return render(request, 'glm_home.html')

# Usuários válidos e suas senhas
USERS = {
    'ges': 'ges',
    'far': {'password': 'far', 'redirect': 'far_home'},
}

def glm_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Verifica se o username existe no dicionário USERS
        if username in USERS:
            user_info = USERS[username]
            # Se o valor for um dicionário (como no caso de 'far'), valida a senha
            if isinstance(user_info, dict):
                if user_info['password'] == password:
                    return redirect(user_info.get('redirect', 'glm_home'))
                else:
                    error_message = 'Senha incorreta. Tente novamente.'
            else:
                if user_info == password:
                    return redirect('glm_home')
                else:
                    error_message = 'Senha incorreta. Tente novamente.'
        else:
            error_message = 'Usuário não encontrado. Tente novamente.'

        # Exibe mensagem de erro caso a validação falhe
        return render(request, 'glm_login.html', {
            'error': error_message
        })

    return render(request, 'glm_login.html')

def listar_medicamentos(request):
    medicamentos = Medicamento.objects.all().order_by('nome')
    for medicamento in medicamentos:
        medicamento.alerta = "ALERTA: Stock baixo" if medicamento.quantidade_stock < 10 else ""
    return render(request, 'listar_medicamentos.html', {'medicamentos': medicamentos})


def criar_medicamento(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        fornecedor = request.POST.get('fornecedor')
        quantidade = request.POST.get('quantidade')

        # Validação básica
        if not nome or not fornecedor or not quantidade:
            return render(request, 'criar_medicamento.html', {
                'error': 'Todos os campos são obrigatórios.'
            })

        try:
            # Convertendo a quantidade para um número inteiro
            quantidade_int = int(quantidade)

            # Verificar se a quantidade é um número positivo
            if quantidade_int < 0:
                raise ValueError("A quantidade não pode ser negativa.")

            # Criação do medicamento
            Medicamento.objects.create(
                nome=nome,
                fornecedor=fornecedor,
                quantidade_stock=quantidade_int,
            )

            return render(request, 'criar_medicamento.html', {
                'success': 'Medicamento adicionado com sucesso!'
            })

        except ValueError as e:
            return render(request, 'criar_medicamento.html', {
                'error': f"Erro na quantidade: {str(e)}"
            })

    return render(request, 'criar_medicamento.html')

def procurar_medicamento_nome(request):
    medicamentos = []
    if 'nome' in request.GET:
        nome = request.GET['nome']
        medicamentos = Medicamento.objects.filter(nome__icontains=nome)

    return render(request, 'procurar_medicamento_nome.html', {'medicamentos': medicamentos})

def aumentar_stock(request):
    if request.method == 'POST':
        medicamento_nome = request.POST.get('medicamento_nome')
        quantidade = int(request.POST.get('quantidade'))

        medicamento = get_object_or_404(Medicamento, nome=medicamento_nome)

        if quantidade > 0:
            medicamento.quantidade_stock += quantidade
            medicamento.save()
            sucesso = f"O estoque do medicamento '{medicamento.nome}' foi aumentado com sucesso!"
            return render(request, 'aumentar_stock.html', {'sucesso': sucesso, 'medicamentos': Medicamento.objects.all()})
        else:
            erro = "A quantidade a ser adicionada deve ser maior que zero."
            return render(request, 'aumentar_stock.html', {'erro': erro, 'medicamentos': Medicamento.objects.all()})

    medicamentos = Medicamento.objects.all()
    return render(request, 'aumentar_stock.html', {'medicamentos': medicamentos})

def alterar_fornecedor(request):
    if request.method == 'POST':
        medicamento_nome = request.POST.get('medicamento_nome')
        novo_fornecedor = request.POST.get('novo_fornecedor')

        if novo_fornecedor:
            # Encontrar o medicamento pelo nome
            medicamento = get_object_or_404(Medicamento, nome=medicamento_nome)

            # Alterar o fornecedor
            medicamento.fornecedor = novo_fornecedor
            medicamento.save()

            sucesso = f"O fornecedor do medicamento '{medicamento.nome}' foi alterado para '{novo_fornecedor}' com sucesso!"
            return render(request, 'alterar_fornecedor.html', {'sucesso': sucesso, 'medicamentos': Medicamento.objects.all()})
        else:
            erro = "Por favor, insira o novo fornecedor."
            return render(request, 'alterar_fornecedor.html', {'erro': erro, 'medicamentos': Medicamento.objects.all()})

    medicamentos = Medicamento.objects.all()
    return render(request, 'alterar_fornecedor.html', {'medicamentos': medicamentos})

def remover_medicamento(request):
    if request.method == 'POST':
        medicamento_nome = request.POST.get('medicamento_nome')
        medicamento = get_object_or_404(Medicamento, nome=medicamento_nome)
        medicamento.delete()  # Remover o medicamento

    # Se for um GET, exibe a lista de medicamentos
    medicamentos = Medicamento.objects.all()
    return render(request, 'remover_medicamento.html', {'medicamentos': medicamentos})

def listar_farmaceuticos(request):

    farmaceuticos = Farmaceutico.objects.all().order_by('nome')

    return render(request, 'listar_farmaceuticos2.html', {'farmaceuticos': farmaceuticos})

def prescrever_medicamento(request):
    if request.method == "POST":
        farmaceutico_nome = request.POST.get("farmaceutico_nome")
        utente_nome = request.POST.get("utente_nome")
        medicamento_nome = request.POST.get("medicamento_nome")
        quantidade = int(request.POST.get("quantidade"))

        try:
            # Recuperar os objetos baseados nos nomes fornecidos
            farmaceutico = Farmaceutico.objects.get(nome=farmaceutico_nome)
            utente = Utente.objects.get(nome=utente_nome)
            medicamento = Medicamento.objects.get(nome=medicamento_nome)

            # Verificar se há estoque suficiente
            if medicamento.quantidade_stock >= quantidade:
                medicamento.quantidade_stock -= quantidade
                medicamento.save()
                message = {"status": "success", "text": "Prescrição realizada com sucesso!"}
            else:
                message = {
                    "status": "error",
                    "text": f"Stock insuficiente para o medicamento {medicamento.nome}. Stock atual: {medicamento.quantidade_stock}.",
                }

        except Medicamento.DoesNotExist:
            message = {"status": "error", "text": "O medicamento selecionado não existe."}
        except Farmaceutico.DoesNotExist:
            message = {"status": "error", "text": "O farmacêutico selecionado não existe."}
        except Utente.DoesNotExist:
            message = {"status": "error", "text": "O utente selecionado não existe."}
    else:
        message = None

    # Passar os objetos para o template
    farmaceuticos = Farmaceutico.objects.all()
    utentes = Utente.objects.all()
    medicamentos = Medicamento.objects.all()

    return render(request, 'prescrever_medicamento.html', {
        'farmaceuticos': farmaceuticos,
        'utentes': utentes,
        'medicamentos': medicamentos,
        'message': message
    })