from django.db import models
#from gpc.models import Medico