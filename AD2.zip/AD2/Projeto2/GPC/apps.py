from django.apps import AppConfig


class GpcConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "GPC"
