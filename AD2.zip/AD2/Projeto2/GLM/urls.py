from django.urls import path
from .views import home, login_usuario, registar_usuario
from django.contrib.auth import views as auth_views

urlpatterns = [
    path("",home,name="home"),

    path('login/', login_usuario, name='login'),
    path('registar/', registar_usuario, name='registar'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]