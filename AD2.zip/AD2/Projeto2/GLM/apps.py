from django.apps import AppConfig


class GlmConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "GLM"
